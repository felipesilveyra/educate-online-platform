# 🚂 GUÍA ULTRA SIMPLE: Railway SIN GitHub (10 minutos)

## ⚠️ IMPORTANTE: NO NECESITAS GITHUB

Esta guía es **100% sin terminal, sin GitHub, sin nada técnico**. Solo copiar y pegar.

---

## 📋 PASO 1: Crear Cuenta en Railway (2 minutos)

### 1.1 Ir a Railway
1. Abre tu navegador
2. Ve a: **https://railway.app**
3. Haz clic en **"Start Free"** (botón azul grande)

### 1.2 Registrarse
1. Elige una opción:
   - ✅ **GitHub** (si tienes cuenta)
   - ✅ **Google** (si tienes Gmail)
   - ✅ **Email** (si prefieres)
2. Completa el registro
3. Verifica tu email

### 1.3 Crear Proyecto
1. Una vez dentro de Railway, haz clic en **"New Project"**
2. Selecciona **"Deploy from Git"**
3. **IMPORTANTE:** Si no tienes GitHub, selecciona **"Deploy from GitHub repo"** y luego **"Create a new repo"**

---

## 🔗 PASO 2: Subir Archivos a GitHub (3 minutos)

### OPCIÓN A: Si tienes GitHub (RECOMENDADO)

1. Ve a **https://github.com/new**
2. Completa:
   - **Repository name:** `educate-online-platform`
   - **Description:** `Plataforma de aprendizaje`
   - **Public:** Selecciona "Public"
3. Haz clic en **"Create repository"**

### OPCIÓN B: Si NO tienes GitHub (MÁS FÁCIL)

1. Ve a **https://github.com/signup**
2. Crea una cuenta (es gratis)
3. Verifica tu email
4. Vuelve a **https://github.com/new**
5. Sigue los pasos de la Opción A

### PASO 2.2: Subir los Archivos

1. En tu repositorio de GitHub, haz clic en **"Add file"** → **"Upload files"**
2. Arrastra estos 6 archivos (o haz clic para seleccionar):
   - `server.js`
   - `package.json`
   - `.env.example`
   - `railway.json`
   - `Procfile`
   - `.gitignore`

3. Abajo, en **"Commit message"**, escribe: `Initial commit`
4. Haz clic en **"Commit changes"**

**¡Listo! Tus archivos están en GitHub**

---

## 🚀 PASO 3: Desplegar en Railway (2 minutos)

### 3.1 Conectar GitHub a Railway

1. Ve a **https://railway.app/dashboard**
2. Haz clic en **"New Project"**
3. Selecciona **"Deploy from GitHub repo"**
4. Selecciona tu repositorio `educate-online-platform`
5. Haz clic en **"Deploy"**

**Railway comenzará a desplegar automáticamente. Espera 2-3 minutos.**

### 3.2 Verificar que está Corriendo

1. En el panel de Railway, ve a **"Deployments"**
2. Deberías ver un estado **"Success"** en verde
3. Copia la URL (algo como: `https://educate-online-platform-production.up.railway.app`)

---

## 🗄️ PASO 4: Crear Base de Datos MySQL (2 minutos)

### 4.1 Agregar MySQL

1. En tu proyecto de Railway, haz clic en **"New"** (arriba a la derecha)
2. Selecciona **"Database"**
3. Selecciona **"MySQL"**
4. Espera a que se cree (1-2 minutos)

### 4.2 Obtener Credenciales

1. En el panel, haz clic en el servicio **"MySQL"**
2. Ve a la pestaña **"Variables"**
3. Copia estos valores (los necesitarás después):
   - `MYSQL_HOST`
   - `MYSQL_USER`
   - `MYSQL_PASSWORD`
   - `MYSQL_DATABASE`

---

## ⚙️ PASO 5: Configurar Variables de Entorno (2 minutos)

### 5.1 En Railway

1. En tu proyecto, haz clic en el servicio **Node.js** (no MySQL)
2. Ve a la pestaña **"Variables"**
3. Haz clic en **"RAW Editor"**
4. **BORRA TODO** lo que está ahí
5. **COPIA Y PEGA** esto (reemplaza los valores en MAYÚSCULAS):

```
DATABASE_URL=mysql://MYSQL_USER:MYSQL_PASSWORD@MYSQL_HOST:3306/MYSQL_DATABASE
DB_HOST=MYSQL_HOST
DB_USER=MYSQL_USER
DB_PASSWORD=MYSQL_PASSWORD
DB_NAME=MYSQL_DATABASE
PORT=3000
JWT_SECRET=mi-clave-secreta-super-segura-12345
SHOPIFY_API_KEY=lo_configuraremos_despues
SHOPIFY_API_SECRET=lo_configuraremos_despues
FRONTEND_URL=https://educateonlineventas.com
BACKEND_URL=https://tu-dominio-railway.railway.app/api
```

6. Haz clic en **"Update"**

### 5.2 Reemplazar Valores Reales

En el texto anterior, reemplaza:
- `MYSQL_HOST` → El valor que copiaste en 4.2
- `MYSQL_USER` → El valor que copiaste en 4.2
- `MYSQL_PASSWORD` → El valor que copiaste en 4.2
- `MYSQL_DATABASE` → El valor que copiaste en 4.2
- `tu-dominio-railway.railway.app` → Tu URL de Railway (de paso 3.2)

---

## ✅ PASO 6: Probar que Funciona (1 minuto)

### 6.1 Abrir la Plataforma

1. Abre un navegador
2. Ve a: `https://tu-dominio-railway.railway.app/api/health`
3. Deberías ver: `{"status":"ok","message":"Servidor funcionando"}`

**Si ves eso, ¡tu backend está funcionando!** 🎉

---

## 🎬 PASO 7: Subir la Plataforma HTML (1 minuto)

### 7.1 Dónde Poner el Archivo

Tienes 2 opciones:

**OPCIÓN A: En Vercel (Gratis y fácil)**
1. Ve a **https://vercel.com**
2. Haz clic en **"Sign Up"**
3. Registrate con GitHub
4. Sube el archivo `plataforma.html`
5. Obtendrás una URL como: `https://tu-proyecto.vercel.app/plataforma.html`

**OPCIÓN B: En GitHub Pages (Gratis)**
1. En tu repositorio de GitHub, sube `plataforma.html`
2. Ve a **"Settings"** → **"Pages"**
3. Selecciona **"main"** como rama
4. Obtendrás una URL como: `https://tu-usuario.github.io/educate-online-platform/plataforma.html`

---

## 🔗 PASO 8: Actualizar la Plataforma HTML (1 minuto)

### 8.1 Editar el Archivo

1. Abre `plataforma.html` en un editor de texto (Notepad, VS Code, etc.)
2. Busca esta línea (alrededor de la línea 9):
```javascript
const API_URL = 'https://educateonlineventas.com/api';
```

3. Reemplázala con tu URL de Railway:
```javascript
const API_URL = 'https://tu-dominio-railway.railway.app/api';
```

4. Guarda el archivo
5. Sube el archivo actualizado a donde lo pusiste (Vercel o GitHub Pages)

---

## 🔔 PASO 9: Configurar Webhook de Shopify (3 minutos)

### 9.1 Crear App en Shopify

1. Ve a tu tienda: **https://tu-tienda.myshopify.com/admin**
2. Menú → **"Configuración"** → **"Apps y canales"**
3. Haz clic en **"Desarrollador"** (abajo a la izquierda)
4. Haz clic en **"Crear una aplicación"**
5. Nombre: `Educate Online Platform`
6. Haz clic en **"Crear aplicación"**

### 9.2 Obtener API Keys

1. En tu app, ve a **"Configuración"**
2. Busca **"Admin API"**
3. Haz clic en **"Mostrar credenciales"**
4. Copia:
   - **API Key**
   - **API Secret**

### 9.3 Actualizar Variables en Railway

1. Ve a tu proyecto en Railway
2. Servicio Node.js → **"Variables"** → **"RAW Editor"**
3. Busca estas líneas:
```
SHOPIFY_API_KEY=lo_configuraremos_despues
SHOPIFY_API_SECRET=lo_configuraremos_despues
```

4. Reemplázalas con tus valores reales:
```
SHOPIFY_API_KEY=tu_api_key_aqui
SHOPIFY_API_SECRET=tu_api_secret_aqui
```

5. Haz clic en **"Update"**

### 9.4 Crear Webhook en Shopify

1. En tu app de Shopify, ve a **"Webhooks"**
2. Haz clic en **"Crear webhook"**
3. Completa:
   - **Evento:** `Orders/create`
   - **URL:** `https://tu-dominio-railway.railway.app/api/webhooks/shopify/order-created`
   - **Formato:** `JSON`
4. Haz clic en **"Guardar"**

---

## 🎉 ¡LISTO!

Tu plataforma está completamente funcional:

✅ Backend en Railway
✅ Base de datos MySQL en Railway
✅ Plataforma HTML en Vercel o GitHub Pages
✅ Webhooks de Shopify configurados
✅ Usuarios se crean automáticamente cuando compran

---

## 📝 URLs Finales

Guarda estos datos:

```
PLATAFORMA: https://tu-proyecto.vercel.app/plataforma.html
BACKEND: https://tu-dominio-railway.railway.app/api
WEBHOOK: https://tu-dominio-railway.railway.app/api/webhooks/shopify/order-created
```

---

## 🐛 Si Algo No Funciona

### Error: "Cannot connect to database"
- Verifica que MySQL esté creado en Railway
- Verifica que las credenciales sean correctas

### Error: "Webhook failed"
- Verifica que la URL sea exacta
- Verifica que `SHOPIFY_API_SECRET` sea correcto

### Videos no cargan
- Abre la consola (F12) en tu navegador
- Verifica que `API_URL` sea correcto en `plataforma.html`

---

## 📞 ¿Necesitas Ayuda?

Si algo no funciona, avísame y te ayudo paso a paso.

**¿Empezamos?**
